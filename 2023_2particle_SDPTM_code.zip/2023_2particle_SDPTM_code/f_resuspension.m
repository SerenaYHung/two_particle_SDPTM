function [ resuspend_v ] = f_resuspension( u_star,par_dia,mode )
%RESUS Summary of this function goes here
% Detailed explanation goes here
% m==1 smooth bed
% m==2 rough bed

% parameters
nu = 10^-6;
m = 10000;
u = linspace(0,2,m);

% produce velocity fluctuations
R_star = u_star * par_dia / nu; 
if mode==1;
    sig = u_star * ( 1 - exp ( -0.093 * R_star^1.3 ) );  % smooth bed
elseif mode==2;
    sig = u_star;                                        % rough bed
end

% pu = 32\exp(-u).*(exp(2*u).*(u.^2-u-16).*(sign(u)-1)+(u.^2+u+32.*exp(u)-16).*(sign(u)+1));
% pu = 1-exp(-u).*(-u.^2/16-u.^2/16+1);
% pu = 1+(- 16*sig^2 + sig*u + u.^2)./(16*sig^2.*exp(u./sig));
pu = 1+ (16\(u./sig).^2+16\(u/sig)-1).*exp(-u/sig);
u_end = find(pu>1);
u = linspace(0,u(u_end(1)),m);
pu = 1+ (16\(u./sig).^2+16\(u/sig)-1).*exp(-u/sig);

resuspend_v = @(susp) interp1(pu, u, susp);


end

