function [ cB] = f_correlated_B( dt, x, z, alpha)
x01=x(1);
x02=x(2);
z01=z(1);
z02=z(2); 
r=(x01-x02)^2+(z01-z02)^2;

f=exp(-alpha*r);
  
% fr=[f,sqrt(r)];%������


Y1=sqrt(dt)*randn(1,1);
Y2=sqrt(dt)*randn(1,1);
Y=[Y1' Y2'];

A2=[1 f;f 1];
if A2==[1 1 ; 1 1]; 
    B=[Y1'+Y2/2, Y1'+Y2/2];
else
    B= Y *chol(A2);
end 

cB=[B(1), B(2)];

end

