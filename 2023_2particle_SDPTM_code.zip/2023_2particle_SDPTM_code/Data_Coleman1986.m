function [H, d, u_star, kappa, lo_s, S]=Data_Coleman1986()
H=0.17; % water depth(m)
d= 105*10^-6; %particle diameter (m)
u_star=0.041; % shear velocity (m/s)
kappa=0.433; %von Karman constant 
lo_s=2.65; % particle density
S=0; %slope

%L=20; %flume length (m)
end

