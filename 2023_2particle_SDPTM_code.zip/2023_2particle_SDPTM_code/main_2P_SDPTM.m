% Two-particle SD-PTM
% Date: 2023/05
% Author: Serena
clc,clear;

%% model parameters
model = 2; % 2 particle model
realization = 800; %次
T = 30; % total simualtion time (s)
dt = 0.05; % time step (s)
n = T/dt; % # of time step
M = 200; % # of paired partilces
%%
beta = sqrt(0.9);
%% Flow condition
[H, d, u_star, kappa, rho_s, S] = Data_Coleman1986;
nu = 10^-6; %kinematic viscosity

%Z0: virtual zero-velocity level of log profile
ks = 2*d; %roughtness height (Wu and Chou, 2003)

if u_star*ks/nu <5 %smooth
    Z0 = nu/9/u_star;
elseif  u_star*ks/nu >70  %rough
    Z0 = ks/30;
else %transition
    Z0 = ks/30+nu/9/u_star;
end

U_bar = @(Z) u_star/kappa.*log(Z./Z0);
%%
g = 9.81; %gravity (m/s^2)
nu = 10^-6; %kinematic viscosity
rho_f = 1; %water density
rho_r = rho_s/rho_f; %relative density

%% settling velocity
Sv = 0; % volume concentration  for concentration effect
ws = f_seltting_velocity(d, rho_r, nu, Sv);

%% diffusivity
dif_x = 0.15*u_star*H;   % assuming constant   ex: 0.033^2 /2 by Robert
%vertical diffucivity Absi et al., 2011
[dif_z, d_dif_z] = f_diffucivity( u_star, H, rho_r, nu, ws, 1 ); % alpha =1;

%% particle reynolds number average
Re_p = sqrt((rho_s - rho_f)*g*d)*d/nu;
%%
z0 = 2.75*d;  %  bed (Hinze 1975; van Rijn 1984a); assuming a particle placed in a interstic betweentwo bed particles
%% resuspension
[resuspend] = f_resuspension(u_star, d,1);  %1 for smooth 2 for rought bed

%% Model
%matrix
X1 = zeros(n,M); Z1 = zeros(n,M);
X = {X1, X1};
Z = {Z1, Z1};
h = waitbar(0,'QAQ');
for e = 1:realization
    waitbar(e/realization)
    for i = 1:M % M-paired for one realization

        % initional position - same position
        z = ones(1,2)*H;
        x = zeros(1,2);
        Z{e,1}(1,i) = H;
        Z{e,2}(1,i) = H;
        %X{e,1}(1,i) = 0;

        for j = 2:n+1

            % Brownian motion - independent
            B = [sqrt(dt)*randn(1,1), sqrt(dt)*randn(1,1)] ;

            % Brownian mtion - correlated
            DX = d/H;
            alpha = 1/DX/DX;
            [cB] = f_correlated_B( dt, x, z, alpha);


            %%
            for k = 1 : 2
                %判斷Z
                if z(k) <= z0 %2.75d
                    w_v = resuspend(rand(1));
                    if w_v > ws
                        Z{e,k}(j,i) = z(k)+(-ws+d_dif_z(z0)+w_v)*dt;
                        %X{e,k}(j,i) = x(k)+( U_bar(z(k)) )*dt ;
                        X{e,k}(j,i) = x(k)+( U_bar(z(k)) )*dt + sqrt(1-beta^2)*sqrt(2*dif_x)*B(k) + beta*sqrt(2*dif_x)*cB(k);

                    elseif w_v <= ws
                        Z{e,k}(j,i) = z0;
                        X{e,k}(j,i) = x(k);
                    end

                else
                    Z{e,k}(j,i) = z(k)+(-ws+d_dif_z(z(k)))*dt+sqrt(1-beta^2)*sqrt(2*dif_z(z(k)))*B(k) + beta*sqrt(2*dif_z(z(k)))*cB(k);
                    X{e,k}(j,i) = x(k)+( U_bar(z(k)) )*dt + sqrt(1-beta^2)*sqrt(2*dif_x)*B(k) + beta*sqrt(2*dif_x)*cB(k);
                end

                %
                if  Z{e,k}(j,i) > H
                    Z{e,k}(j,i) = H;
                elseif   Z{e,k}(j,i) <= z0
                    Z{e,k}(j,i) = z0;

                end
                z(k) = Z{e,k}(j,i);
                x(k) = X{e,k}(j,i);

            end
        end
    end
end
close (h)
Data = X;
[X_total_mean, X_total_var, X_var_en_mean, X_var_en_var] = A_ensemble_statistics(Data, realization, M, model);

Data = Z;
[Z_total_mean, Z_total_var, Z_var_en_mean, Z_var_en_var] = A_ensemble_statistics(Data, realization, M, model);

% layer = 12;
% [C, Layer_C, C_z, C_depositd_bead] = Concentration_count(layer, H, z0, Z, realization, n, model  );
% t = 0:dt:T;