function [ws] = f_seltting_velocity(d, rho_r, nu, Sv)
R=rho_r-1;
g=9.81; 
% �̷ӨҤl�j�p�P�_
if d <= 1e-4
    ws = R*g*d^2/(18*nu);    

elseif d> 1e-4 && d<= 1e-3  % ���ӬO�o��
    ws = 10*nu/d*(sqrt(1+0.01*R*g*d^3/nu^2)-1);
else
    ws = 1.1*sqrt(R*g*d);   
end

%concentration effect 
k=0.75; % Cai 
ws=ws / (1 + 1.24*k*Sv^(1/3));
end