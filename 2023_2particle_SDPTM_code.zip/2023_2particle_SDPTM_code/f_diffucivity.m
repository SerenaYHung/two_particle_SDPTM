function [ epsilon_s, d_epsilon_s ] = f_diffucivity( u_star, H, Rs, nu, ws, alpha )
% Absi et al., 2011
syms y
C_mu = 0.09;
g = 9.81;

Re_tau = H*u_star/nu;
y_plus = y*u_star/nu;

A_t = 0.46*Re_tau - 5.98;
a_t = 0.34*Re_tau - 11.5;
V_t = nu * y_plus * exp(-(y_plus + a_t)/A_t);

A_k = 0.58*Re_tau-17;% for Re_tau > 650
a_k = 0.3*Re_tau-100; % for Re_tau > 700

k = u_star^2 * (1/sqrt(C_mu)).*exp(-(y_plus-a_k)./A_k);%TKE

St = ws/(1-1/Rs)/g*C_mu*k/V_t/alpha;
SCt=St/(1-1/Rs)+1/(1+St);

f = SCt*V_t;
df = diff(f,y); %particle epsilon/ partical z

epsilon_s = matlabFunction(f);
d_epsilon_s = matlabFunction(df);

% epsilon_s = F(z);
% dif_epsilon_s = dF(z);

end